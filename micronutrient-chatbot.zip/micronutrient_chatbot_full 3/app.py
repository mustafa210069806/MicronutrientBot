from flask import Flask, request, jsonify, render_template
import os
import uuid
from google.cloud import dialogflow_v2 as dialogflow
import csv
from services.utils import clean_food_names, convert_weight_to_kg, convert_height_to_cm
from services.rdi_service import calculate_rdi_percentage
from services.static_foods import get_static_food_recommendations
from services.usda_service import get_nutrient_amount
from services.intent_handlers.education_handlers import handle_get_rdi_for_nutrient
from services.intent_handlers.condition_handlers import (
    handle_check_micronutrient_condition,
    handle_yes_food_suggestion,
)

from services.intent_handlers.nutrient_handlers import (
    handle_nutrient_based,
    handle_get_nutrient_amount,
    handle_get_full_nutrient_profile,
    handle_nutrient_deficiency,
    handle_nutrient_overdose,
)

from services.intent_handlers.profile_handlers import (
    handle_capture_user_profile,
    handle_yes_rdi,
)

from services.intent_handlers.education_handlers import (
    handle_general_nutrition_info,
    handle_explain_nutrient_role,
    handle_list_foods_high_in_nutrient,
)
from services.knowledge_service import load_general_nutrition_knowledge  # Import the new function
from services.intent_handlers.meal_handlers import handle_meal_suggestion

os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "dialogflow_key.json"


app = Flask(__name__)
current_session_id = str(uuid.uuid4())
print(f"[DEBUG] Generated new session ID at server start: {current_session_id}")

# Dialogflow intent detection
def detect_intent_texts(project_id, session_id, text, language_code):
    session_client = dialogflow.SessionsClient()
    session = session_client.session_path(project_id, session_id)

    text_input = dialogflow.TextInput(text=text, language_code=language_code)
    query_input = dialogflow.QueryInput(text=text_input)

    response = session_client.detect_intent(
        request={
            "session": session,
            "query_input": query_input,
        }
    )
    return response

# Chat interface
@app.route("/")
def index():
    return render_template("chat.html")

@app.route("/send-message", methods=["POST"])
def send_message():
    try:
        data = request.get_json()
        user_message = data.get("message", "")
        response = detect_intent_texts(
            project_id="micronutrientbot-jkmj",
            session_id=current_session_id,
            text=user_message,
            language_code="en"
        )
        if response.query_result.fulfillment_text:
            bot_reply = response.query_result.fulfillment_text
        elif response.query_result.fulfillment_messages:
            messages = response.query_result.fulfillment_messages
            if messages and messages[0].text and messages[0].text.text:
                bot_reply = messages[0].text.text[0]
            else:
                bot_reply = "Sorry, I didn’t understand that."
        else:
            bot_reply = "Sorry, I didn’t understand that."
        print("[DEBUG] Fulfillment text:", bot_reply)
        return jsonify({"reply": bot_reply})
    except Exception as e:
        print(f"[ERROR] Exception during send_message: {e}")
        return jsonify({"reply": " Sorry something went wrong on the server. please try again"})

@app.route("/webhook", methods=["POST"])
def webhook():
    req = request.get_json(force=True)
    global session_data
    session_id = req.get("session", "")
    
    print("DEBUG: Full webhook request:", req)

    intent_name = req.get("queryResult", {}).get("intent", {}).get("displayName", "")
    print("DEBUG: Matched intent:", intent_name)

    if intent_name == "CheckMicronutrientCondition":
        return handle_check_micronutrient_condition(req,)

    elif intent_name == "NutrientBased":
        return handle_nutrient_based(req)
    elif intent_name == "Yes_FoodSuggestionIntent":
        return handle_yes_food_suggestion(req,)
    elif intent_name == "GetNutrientAmount":
        return handle_get_nutrient_amount(req)

    elif intent_name == "CaptureUserProfile":
        return handle_capture_user_profile(req)


    elif intent_name == "Yes_RDIIntent":
        return handle_yes_rdi(req)
    
    elif intent_name == "NoIntent":
        from services.utils import handle_no_intent
        return handle_no_intent(req)

    elif intent_name == "BalancedDiet":
        nutrition_knowledge = load_general_nutrition_knowledge()
        return handle_general_nutrition_info(req, nutrition_knowledge)

    elif intent_name == "GeneralNutritionInfo":
        nutrition_knowledge = load_general_nutrition_knowledge()  
        return handle_general_nutrition_info(req, nutrition_knowledge) 

    elif intent_name == "ExplainNutrientRole":  
        return handle_explain_nutrient_role(req)

    elif intent_name == "GetRDIForNutrient":
        return handle_get_rdi_for_nutrient(req)
    elif intent_name == "ListFoodsHighInNutrient":
        return handle_list_foods_high_in_nutrient(req)

    elif intent_name == "GetNutrientRDI":
        return handle_get_rdi_for_nutrient(req)

    elif intent_name == "NutrientDeficiencyEffect": 
        return handle_nutrient_deficiency(req)

    elif intent_name == "RequestMealForNutrient":
        return handle_meal_suggestion(req)
    elif intent_name == "Yes_MealSuggestionIntent":
        return handle_meal_suggestion(req)

    elif intent_name == "NutrientOverdoseRisk":
        return handle_nutrient_overdose(req)

    elif intent_name == "Default Welcome Intent":
        return jsonify({
            "fulfillmentMessages": [{"text": {"text": ["Hi there! I’m your nutrition assistant.'."]}}]
        })

    elif intent_name == "Default Fallback Intent":
        return jsonify({
            "fulfillmentMessages": [{"text": {"text": ["Sorry, I didn’t get that. Try saying something like 'I have anemia' or 'what’s the vitamin C in oranges'."]}}]
        })

    return jsonify({
        "fulfillmentMessages": [{"text": {"text": ["I'm not sure how to help with that yet."]}}]
    })

if __name__ == "__main__":
    app.run(debug=True, port=8080)