import json
from rapidfuzz import fuzz


with open("services/data/symptom_nutrient_map.json", encoding="utf-8") as f:
    SYMPTOM_MAP = json.load(f)

def find_symptom_match(user_text, threshold=80):
    """
    Perform fuzzy matching to find the best matching symptom for user input.
    Returns a dict with symptom, nutrient, explanation, etc., or None.
    """
    best_score = 0
    best_entry = None

    for entry in SYMPTOM_MAP:
        for phrase in [entry["symptom"]] + entry["aliases"]:
            score = fuzz.token_set_ratio(user_text.lower(), phrase.lower())
            if score > best_score:
                best_score = score
                best_entry = entry

    return best_entry if best_score >= threshold else None

def load_condition_data():
    with open("services/data/condition_nutrient_map.json", "r") as file:
        return json.load(file)

def find_condition_match(user_input):
    conditions = load_condition_data()
    user_input = user_input.lower()

   
    for condition in conditions:
        for alias in condition['aliases']:
            if alias in user_input:
                return condition
    
    return None