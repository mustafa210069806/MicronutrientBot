from flask import jsonify
from services.knowledge_repository import find_symptom_match
from services.food_repository import get_foods_for_nutrient

def handle_check_micronutrient_condition(req):
    parameters = req.get("queryResult", {}).get("parameters", {})
    symptom_value = parameters.get("symptom")

    if symptom_value:
        symptom_match = find_symptom_match(symptom_value)
    else:
        user_text = req.get("queryResult", {}).get("queryText", "").lower()
        symptom_match = find_symptom_match(user_text)
    if symptom_match:
        nutrient = symptom_match["nutrient"]
        symptom = symptom_match["symptom"]
        explanation = symptom_match["explanation"]
        match_type = symptom_match.get("type", "symptom")

        nutrient_str = ", ".join(nutrient)
        if match_type == "condition":
            response_text = (
                f"{explanation} Would you like food suggestions to support higher intake of {nutrient_str}?"
            )
        else:
            response_text = (
                f"{explanation} Would you like food suggestions to help with {nutrient_str}?"
            )

        return jsonify({
            "fulfillmentMessages": [{"text": {"text": [response_text]}}],
            "outputContexts": [
                {
                    "name": f"{req['session']}/contexts/nutrition_context",
                    "lifespanCount": 20,
                    "parameters": {
                        "symptom": [symptom],
                        "last_symptom": symptom,
                        "last_nutrient": nutrient
                    }
                },
                {
                    "name": f"{req['session']}/contexts/awaiting_food_confirmation",
                    "lifespanCount": 5,
                    "parameters": {
                        "symptom": [symptom],
                        "last_symptom": symptom,
                        "last_nutrient": nutrient
                    }
                }
            ]
        })


    response_text = (
        "I couldn't recognise that symptom. Try using terms like 'tiredness', or 'weak bones'. "
        
    )

    return jsonify({
        "fulfillmentMessages": [{"text": {"text": [response_text]}}],
        "outputContexts": [{
            "name": f"{req['session']}/contexts/symptom_help_context",
            "lifespanCount": 5,
            "parameters": {
                "awaiting_symptom_list": True
            }
        }]
    })



from services.food_repository import get_foods_for_nutrient

def handle_yes_food_suggestion(req):
    output_contexts = req.get("queryResult", {}).get("outputContexts", [])
    nutrient = None

    for ctx in output_contexts:
        if "nutrition_context" in ctx.get("name", ""):
            nutrient = ctx["parameters"].get("last_nutrient")
            break

    if not nutrient:
        return jsonify({
            "fulfillmentMessages": [{"text": {"text": ["I'm not sure which nutrient you're referring to. Could you repeat your concern?"]}}]
        })

    if isinstance(nutrient, list):
        all_foods = []
        for n in nutrient:
            all_foods.extend(get_foods_for_nutrient(n))
      
        seen = set()
        unique_foods = []
        for food in all_foods:
            if food["food"] not in seen:
                seen.add(food["food"])
                unique_foods.append(food)
        foods = unique_foods
    else:
        foods = get_foods_for_nutrient(nutrient)
    if not foods:
        return jsonify({
            "fulfillmentMessages": [{"text": {"text": [f"Sorry, I couldn't find foods rich in {nutrient}."]}}]
        })

    response_lines = []
    if isinstance(nutrient, list):
        for n in nutrient:
            foods_for_n = get_foods_for_nutrient(n)
            if foods_for_n:
                names = ', '.join([f["food"] for f in foods_for_n])
                response_lines.append(f"{n.title()}: {names}")
        response_text = (
            "Here are some foods rich in the nutrients you mentioned:\n" +
            "\n".join(response_lines) +
            f"\nWould you like a meal suggestion high in {nutrient[0]}?"
        )
    else:
        food_names = [f["food"] for f in foods]
        response_text = (
            f"Here are some foods rich in {nutrient}: {', '.join(food_names)}. "
            f"Would you like a meal suggestion high in {nutrient}?"
        )

    return jsonify({
        "fulfillmentMessages": [{"text": {"text": [response_text]}}]
    })