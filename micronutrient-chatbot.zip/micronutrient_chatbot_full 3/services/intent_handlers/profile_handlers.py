from flask import jsonify
from services.utils import convert_weight_to_kg

def handle_capture_user_profile(req):
    parameters = req['queryResult']['parameters']
    age = parameters.get("age")
    if isinstance(age, dict) and "amount" in age:
        age = int(float(age["amount"]))
    elif isinstance(age, (float, str, int)):
        age = int(float(age))
    else:
        age = None
    weight = str(parameters.get("weight")).strip() if parameters.get("weight") else None
    height = str(parameters.get("height")).strip() if parameters.get("height") else None
    gender = str(parameters.get("gender")).strip().lower() if parameters.get("gender") else None

    print("DEBUG: Captured user profile:", age, weight, gender, height)
    if weight:
        try:
            weight_in_kg = convert_weight_to_kg(str(weight))
            if weight_in_kg:
                weight = weight_in_kg
                print(f"DEBUG: Converted weight to kg: {weight} kg")
        except:
            weight = None

    missing_fields = []
    if not age:
        missing_fields.append("age")
    if not gender:
        missing_fields.append("gender")
    if not weight:
        missing_fields.append("weight")
    if not height:
        missing_fields.append("height")

    output_contexts = req['queryResult'].get('outputContexts', [])
    nutrient = food = None
    amount_per_100g = None
    for ctx in output_contexts:
        if 'awaiting_user_profile' in ctx.get('name', ''):
            nutrient = ctx['parameters'].get('nutrient')
            food = ctx['parameters'].get('food')
            amount_per_100g = ctx['parameters'].get('amount') or ctx['parameters'].get('amount.original', '')
        elif 'awaiting_rdi' in ctx.get('name', '') and not amount_per_100g:
            amount_per_100g = ctx['parameters'].get('amount') or ctx['parameters'].get('amount.original', '')

    amount_per_100g = str(amount_per_100g).strip()

    if missing_fields:
        next_question = None
        for field in ["age", "gender", "weight", "height"]:
            if field in missing_fields:
                if field == "age":
                    next_question = "How old are you?"
                elif field == "gender":
                    next_question = "Are you male or female?"
                elif field == "weight":
                    next_question = "What’s your weight in kg?"
                elif field == "height":
                    next_question = "What’s your height in cm or feet and inches?"
                break

        return jsonify({
            "fulfillmentMessages": [{"text": {"text": [next_question]}}],
            "outputContexts": [{
                "name": f"{req['session']}/contexts/awaiting_user_profile",
                "lifespanCount": 5,
                "parameters": {
                    "age": age,
                    "weight": weight,
                    "gender": gender,
                    "height": height,
                    "nutrient": nutrient,
                    "food": food,
                    "amount": amount_per_100g
                }
            }]
        })


    if nutrient and ctx['parameters'].get('mealtype') is not None:
        mealtype = ctx['parameters'].get('mealtype', '').strip().lower()
        if mealtype in ["", "meal", "any", None]:
            mealtype = "main meal"
        diet_type = ctx['parameters'].get('diet_type', "")
        from services.intent_handlers.meal_handlers import handle_meal_suggestion
        req['queryResult']['parameters'] = {
            "nutrient": nutrient,
            "mealtype": mealtype,
            "diet_type": diet_type
        }
       
        req['queryResult']['outputContexts'] = [
            c for c in output_contexts if 'awaiting_user_profile' not in c['name']
        ]
        return handle_meal_suggestion(req)

    from services.rdi_service import calculate_rdi_percentage

   
    if food and amount_per_100g:
        try:
            unit = "mg" if str(amount_per_100g).replace('.', '', 1).isdigit() else "µg"
            gender = gender.lower() if isinstance(gender, str) else str(gender[0]).lower()
            if isinstance(age, dict) and "amount" in age:
                age = int(float(age["amount"]))
            elif isinstance(age, (float, str, int)):
                age = int(float(age))
            else:
                age = None
            weight_kg = float(weight) if isinstance(weight, (int, float)) else convert_weight_to_kg(str(weight))
            import re
            height_cm = float(re.findall(r"\d+(?:\.\d+)?", str(height))[0])
            amount_val = float(str(amount_per_100g).split()[0])

            percentage = calculate_rdi_percentage(
                amount=amount_val,
                unit=unit,
                nutrient=nutrient,
                gender=gender,
                age=age,
                weight_kg=weight_kg,
                height_cm=height_cm
            )

            if percentage is not None:
                response_text = (
                    f"Thanks! Based on your profile, 100g of {food} provides about "
                    f"{round(percentage)}% of your daily {nutrient} requirement."
                )
            else:
                response_text = (
                    "Sorry, I couldn't calculate the percentage because some data is missing."
                )
        except Exception as e:
            print("DEBUG: RDI calculation error:", e)
            response_text = (
                "Sorry, I couldn’t calculate the percentage because something "
                "was missing or incorrect."
            )

        return jsonify({
            "fulfillmentText": response_text,
            "outputContexts": [{
                "name": f"{req['session']}/contexts/user_profile",
                "lifespanCount": 50,
                "parameters": {
                    "age": age, "weight": weight, "gender": gender, "height": height
                }
            }]
        })

  
    if nutrient:
        mealtype = ctx['parameters'].get('mealtype', 'any')
        diet_type = ctx['parameters'].get('diet_type', '')
        from services.intent_handlers.meal_handlers import handle_meal_suggestion
        req['queryResult']['parameters'] = {
            "nutrient": nutrient,
            "mealtype": mealtype,
            "diet_type": diet_type
        }
        req['queryResult']['outputContexts'] = [
            c for c in output_contexts if 'awaiting_user_profile' not in c['name']
        ]
        return handle_meal_suggestion(req)

    return jsonify({
        "fulfillmentText": "Thanks! Your profile is saved.",
        "outputContexts": [{
            "name": f"{req['session']}/contexts/user_profile",
            "lifespanCount": 50,
            "parameters": {
                "age": age, "weight": weight, "gender": gender, "height": height
            }
        }]
    })


def handle_yes_rdi(req):
    output_contexts = req.get("queryResult", {}).get("outputContexts", [])
    nutrient = food = amount = ""
    user_profile = {}
    for ctx in output_contexts:
        if "awaiting_rdi" in ctx["name"]:
            nutrient = ctx["parameters"].get("nutrient", "")
            food = ctx["parameters"].get("food", "")
            amount = ctx["parameters"].get("amount", "")
        elif "user_profile" in ctx["name"]:
            user_profile = ctx.get("parameters", {})

    if nutrient and food and amount:
        if all(user_profile.get(k) for k in ["age", "gender", "weight", "height"]):
            req['queryResult']['parameters'] = {
                "age": user_profile.get("age"),
                "gender": user_profile.get("gender"),
                "weight": user_profile.get("weight"),
                "height": user_profile.get("height")
            }
            return handle_capture_user_profile(req)

        return jsonify({
            "fulfillmentMessages": [{"text": {"text": ["How old are you?"]}}],
            "outputContexts": [{
                "name": f"{req['session']}/contexts/awaiting_user_profile",
                "lifespanCount": 5,
                "parameters": {
                    "nutrient": nutrient,
                    "food": food,
                    "amount": amount,
                    "age": "", "gender": "", "weight": "", "height": ""
                }
            }]
        })

    return jsonify({
        "fulfillmentMessages": [{"text": {"text": ["Sorry, I couldn’t process that."]}}]
    })

def handle_reset_user_profile(req):
    return jsonify({
        "fulfillmentText": "Okay, I’ve reset your profile information. You can start again whenever you’re ready.",
        "outputContexts": [{
            "name": f"{req['session']}/contexts/user_profile",
            "lifespanCount": 0,
            "parameters": {}
        }]
    })