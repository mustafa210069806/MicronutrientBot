import pandas as pd
from flask import jsonify
from services.meal_service import get_meals
import random
from services.utils import convert_height_to_cm, convert_weight_to_kg

def handle_meal_suggestion(req):
    user_rdi = None  
    parameters = req.get("queryResult", {}).get("parameters", {})
    nutrient = parameters.get("nutrient")
    
    if not nutrient:
        nutrition_ctx = next(
            (c for c in req["queryResult"]["outputContexts"]
             if c["name"].endswith("/nutrition_context")),
            {}
        )
        nutrient = nutrition_ctx.get("parameters", {}).get("last_nutrient")

   
    if isinstance(nutrient, list):
        nutrient = nutrient[0]
   
    nutrient_map = {
        "vitamin c": "vitamin_c",
        "vitamin a": "vitamin_a",
        "vitamin d": "vitamin_d",
        "vitamin b12": "vitamin_b12",
        "iron": "iron",
        "calcium": "calcium",
        "magnesium": "magnesium",
        "zinc": "zinc",
        "folate": "vitamin_b9"
    }
    nutrient = nutrient_map.get(nutrient.lower(), nutrient.lower())
    diet_type = parameters.get("diet_type", "Omnivore") 
    meal_type = (parameters.get("mealtype") or "any").title()  
    if meal_type.lower() in ["any", "meal", "meals"]:
        meal_type = "Main Meal"

    if not nutrient:
        return jsonify({
            "fulfillmentText": "Which nutrient are you trying to get more of?"
        })

    meals = get_meals(target_nutrient=nutrient, diet_type=diet_type, meal_type=meal_type)

    from services.rdi_service import get_custom_rdi

   
    profile_ctx = next(
        (c for c in req["queryResult"]["outputContexts"] 
         if c["name"].endswith("/user_profile")),
        {}
    )
    params_ctx = profile_ctx.get("parameters", {})

    age    = params_ctx.get("age")
    gender = params_ctx.get("gender")
    weight = params_ctx.get("weight")
    height = params_ctx.get("height")

   
    for var_name in ("age", "gender", "weight", "height"):
        val = locals()[var_name]
        if isinstance(val, list) and val:
            locals()[var_name] = val[0]

    
    if not all([gender, age, weight, height]):
        return jsonify({
            "fulfillmentText": "How old are you?",
            "outputContexts": [
                {
                    "name": f"{req['session']}/contexts/awaiting_user_profile",
                    "lifespanCount": 5,
                    "parameters": {
                        "nutrient": nutrient,
                        "mealtype": meal_type,
                        "diet_type": diet_type
                    }
                }
            ]
        })

    # Map nutrient to column name in dataset
    column_lookup = {
        "iron": "Iron_mg",
        "calcium": "Calcium_mg",
        "vitamin c": "Vitamin_C_mg",
        "vitamin b12": "Vitamin_B12_mcg",
        "vitamin a": "Vitamin_A_mcg",
        "vitamin d": "Vitamin_D_mcg",
        "vitamin k": "Vitamin_K_mcg",
        "zinc": "Zinc_mg",
        "magnesium": "Magnesium_mg",
        "iodine": "Iodine_mcg",
        "selenium": "Selenium_mcg",
        "folate": "Folate_mcg",
        "protein": "Protein_g",
        "calories": "Calories_kcal"
    }
    rdi_msg = ""

    if meals.empty:
        # Fallback to alternate meal type but keep diet type fixed
        fallback_type = "Main Meal" if meal_type.lower() != "main meal" else "Snack"
        fallback_meals = get_meals(target_nutrient=nutrient, diet_type=diet_type, meal_type=fallback_type)

        if not fallback_meals.empty:
            fallback_meal = fallback_meals.sample(1).iloc[0]
            fallback_name = fallback_meal["Meal_Name"]
            ingredients = []
            for i in range(1, 6):
                ing = fallback_meal.get(f"Main_Ingredient_{i}")
                amt = fallback_meal.get(f"Main_Ingredient_{i}_Grams")
                if pd.notna(ing) and pd.notna(amt):
                    ingredients.append(f"{amt}g {ing}")
            ingredient_text = ", ".join(ingredients)
            instructions = fallback_meal.get("Instructions", "No instructions provided.")
            # Ensure nutrient is a string (in case it was overwritten by float)
            nutrient_str = str(nutrient).lower() if isinstance(nutrient, str) else ""
            nutrient_column = column_lookup.get(nutrient_str)
            try:
                if nutrient_column and fallback_meal.get(nutrient_column) not in [None, ""]:
                    meal_value = float(fallback_meal[nutrient_column])
                    if all([gender, age, weight, height]):
                        # Ensure clean strings from context arrays
                        if isinstance(gender, list):
                            gender = gender[0]
                        if isinstance(height, list):
                            height = height[0]
                        if isinstance(weight, list):
                            weight = weight[0]
                        if isinstance(age, list):
                            age = age[0]

                        gender = str(gender).strip().lower()
                        height_cm = float(str(height).replace("cm", "").strip())
                        weight_kg = float(str(weight).replace("kg", "").strip())
                        if isinstance(age, dict) and "amount" in age:
                            age_int = int(float(age["amount"]))
                        elif isinstance(age, (float, str, int)):
                            age_int = int(float(age))
                        else:
                            age_int = None

                        user_rdi = get_custom_rdi(nutrient_str, gender, age_int, weight_kg, height_cm)
                        if user_rdi:
                            percent = round((meal_value / user_rdi) * 100)
                            rdi_msg = f"\n This provides about {percent}% of your daily {nutrient} requirement."
            except Exception as e:
                print(f"RDI calculation error: {e}")
                rdi_msg = ""

            nutrient = nutrient if isinstance(nutrient, str) and nutrient.strip() else "the nutrient"
            meal_type = meal_type if isinstance(meal_type, str) and meal_type.strip() else "meal"
            fallback_type = fallback_type if isinstance(fallback_type, str) and fallback_type.strip() else "main meal"
            diet_type = diet_type if isinstance(diet_type, str) and diet_type.strip() else "omnivore"

            meal_type_label = meal_type.lower()
            if meal_type_label in ["any", "meal"]:
                meal_type_label = "meal"
            else:
                meal_type_label = meal_type_label + "s"

            fallback_response = (
                f"Sorry, I couldn't find any {diet_type.lower()} {meal_type_label} high in {nutrient}, "
                f"but here’s a {diet_type.lower()} {fallback_type.lower()} instead:\n"
                f" *{fallback_name}*\n"
                f" Ingredients: {ingredient_text}\n"
                f" Instructions: {instructions}{rdi_msg}"
            )
            return jsonify({"fulfillmentText": fallback_response})

        # If no fallback found either
        meal_type_label = meal_type.lower() if meal_type else ""
        diet_type_label = diet_type.lower() if diet_type else ""
        parts = [diet_type_label, meal_type_label]
        query_desc = " ".join([p for p in parts if p]) or "meal"
        return jsonify({
            "fulfillmentText": f"Sorry, I couldn't find any {query_desc}s high in {nutrient} right now."
        })

    meal = meals.sample(1).iloc[0]
    meal_name = meal['Meal_Name']
    ingredients = []
    for i in range(1, 6):
        ing = meal.get(f"Main_Ingredient_{i}")
        amt = meal.get(f"Main_Ingredient_{i}_Grams")
        if pd.notna(ing) and pd.notna(amt):
            ingredients.append(f"{amt}g {ing}")
    ingredient_text = ", ".join(ingredients)
    instructions = meal["Instructions"]

    # Ensure nutrient is a string (in case it was overwritten by float)
    nutrient_str = str(nutrient).lower() if isinstance(nutrient, str) else ""
    nutrient_column = column_lookup.get(nutrient_str)
    try:
        if nutrient_column and meal.get(nutrient_column) not in [None, ""]:
            meal_value = float(meal[nutrient_column])
            if all([gender, age, weight, height]):
                # Ensure clean strings from context arrays
                if isinstance(gender, list):
                    gender = gender[0]
                if isinstance(height, list):
                    height = height[0]
                if isinstance(weight, list):
                    weight = weight[0]
                if isinstance(age, list):
                    age = age[0]

                gender = str(gender).strip().lower()
                height_cm = float(str(height).replace("cm", "").strip())
                weight_kg = float(str(weight).replace("kg", "").strip())
                if isinstance(age, dict) and "amount" in age:
                    age_int = int(float(age["amount"]))
                elif isinstance(age, (float, str, int)):
                    age_int = int(float(age))
                else:
                    age_int = None

                user_rdi = get_custom_rdi(nutrient_str, gender, age_int, weight_kg, height_cm)
                if user_rdi:
                    percent = round((meal_value / user_rdi) * 100)
                    rdi_msg = f"\n This rougly provides {percent}% of your daily {nutrient} requirement depending on types you use."
    except Exception as e:
        print(f"RDI calculation error: {e}")
        rdi_msg = ""

    nutrient_line = ""
    if nutrient_column and meal.get(nutrient_column) not in [None, ""]:
        try:
            meal_value = float(meal[nutrient_column])
            nutrient_line = f"**This meal contains approximately {meal_value} mg of {nutrient}.**\n"
        except:
            nutrient_line = ""

    response_text = (
        f"Here’s a {diet_type.lower()} {meal_type.lower()} that’s high in {nutrient}:\n\n"
        f"{meal_name}\n\n"
        f"Ingredients: {ingredient_text}\n"
        f"Instructions: {instructions}\n\n"
    )

    if nutrient_column and meal.get(nutrient_column) not in [None, ""]:
        try:
            meal_value = float(meal[nutrient_column])
            response_text += f"This meal contains approximately {meal_value} mg of {nutrient}.\n"
        except:
            pass

    if user_rdi and meal_value:
        response_text += (
            f"This roughly provides {percent}% of your daily {nutrient} requirement "
            f"(based on your profile — this is an estimate, not an exact value)."
        )

    return jsonify({"fulfillmentText": response_text})
