from flask import jsonify
import os
import json
from services.knowledge_service import get_general_nutrition_response


def handle_explain_nutrient_role(req):
    parameters = req.get("queryResult", {}).get("parameters", {})
    nutrient_key = parameters.get("nutrient", "")
    if isinstance(nutrient_key, list):
        nutrient_key = nutrient_key[0]
    nutrient_key = nutrient_key.lower().replace(" ", "_")

    current_dir = os.path.dirname(__file__)
    nutrient_path = os.path.join(current_dir, "..", "data", "nutrient_info.json")
    with open(nutrient_path, encoding="utf-8") as f:
        nutrient_info = json.load(f)

    nutrient = nutrient_info.get(nutrient_key)
    if nutrient:
        role = nutrient.get("role", "No role information available.")
        response_text = f"{nutrient['name']} plays an important role in the body: {role}"
    else:
        response_text = f"Sorry, I don’t have information about {nutrient_key}."

    return jsonify({
        "fulfillmentMessages": [
            {"text": {"text": [response_text]}}
        ]
    })


def handle_list_foods_high_in_nutrient(req):
    parameters = req.get("queryResult", {}).get("parameters", {})
    nutrient_key = parameters.get("nutrient", "")
    if isinstance(nutrient_key, list):
        nutrient_key = nutrient_key[0] if nutrient_key else ""
    if not nutrient_key:
        return jsonify({
            "fulfillmentMessages": [{"text": {"text": ["Sorry, I couldn’t tell which nutrient you meant. Try asking again."]}}]
        })
    nutrient_key = nutrient_key.lower().replace(" ", "_")

    current_dir = os.path.dirname(__file__)
    nutrient_path = os.path.join(current_dir, "..", "data", "nutrient_info.json")
    try:
        with open(nutrient_path, encoding="utf-8") as f:
            nutrient_info = json.load(f)
    except Exception as e:
        print(f"[ERROR] Failed to load nutrient_info.json: {e}")
        return jsonify({
            "fulfillmentMessages": [{"text": {"text": ["Oops! I had trouble accessing the nutrient database."]}}]
        })

    nutrient = nutrient_info.get(nutrient_key)
    if nutrient and "sources" in nutrient:
        foods = ", ".join(nutrient["sources"])
        response_text = f"Here are some foods rich in {nutrient['name']}: {foods}."
    else:
        response_text = f"Sorry, I couldn’t find foods high in {nutrient_key}."

    return jsonify({
        "fulfillmentMessages": [{"text": {"text": [response_text]}}]
    })


def handle_general_nutrition_info(req, nutrition_knowledge):
    user_question = req.get("queryResult", {}).get("queryText", "").lower()
    response = get_general_nutrition_response(user_question)
    return jsonify({
        "fulfillmentMessages": [{"text": {"text": [response]}}]
    })



def handle_get_rdi_for_nutrient(req):
    parameters = req.get("queryResult", {}).get("parameters", {})
    nutrient_key = parameters.get("nutrient", "")
    if isinstance(nutrient_key, list):
        nutrient_key = nutrient_key[0]
    nutrient_key = nutrient_key.lower().replace(" ", "_")

    current_dir = os.path.dirname(__file__)
    nutrient_path = os.path.join(current_dir, "..", "data", "nutrient_info.json")

    try:
        with open(nutrient_path, encoding="utf-8") as f:
            nutrient_info = json.load(f)
    except Exception as e:
        print(f"[ERROR] Failed to load nutrient_info.json: {e}")
        return jsonify({
            "fulfillmentMessages": [{"text": {"text": ["Sorry, I couldn't access nutrient data right now."]}}]
        })

    nutrient = nutrient_info.get(nutrient_key)
    if nutrient and "rdi" in nutrient:
        response_text = f"The recommended daily intake for {nutrient['name']} is: {nutrient['rdi']}."
    else:
        response_text = f"Sorry, I don’t have the RDI information for {nutrient_key}."

    return jsonify({
        "fulfillmentMessages": [{"text": {"text": [response_text]}}]
    })
from flask import jsonify
import os
import json
from services.knowledge_service import get_general_nutrition_response


def handle_explain_nutrient_role(req):
    parameters = req.get("queryResult", {}).get("parameters", {})
    nutrient_key = parameters.get("nutrient", "")
    if isinstance(nutrient_key, list):
        nutrient_key = nutrient_key[0]
    nutrient_key = nutrient_key.lower().replace(" ", "_")

    current_dir = os.path.dirname(__file__)
    nutrient_path = os.path.join(current_dir, "..", "data", "nutrient_info.json")
    with open(nutrient_path, encoding="utf-8") as f:
        nutrient_info = json.load(f)

    nutrient = nutrient_info.get(nutrient_key)
    if nutrient:
        role = nutrient.get("role", "No role information available.")
        response_text = f"{nutrient['name']} plays an important role in the body: {role}"
    else:
        response_text = f"Sorry, I don’t have information about {nutrient_key}."

    return jsonify({
        "fulfillmentMessages": [
            {"text": {"text": [response_text]}}
        ]
    })


def handle_list_foods_high_in_nutrient(req):
    parameters = req.get("queryResult", {}).get("parameters", {})
    nutrient_key = parameters.get("nutrient", "")
    if isinstance(nutrient_key, list):
        nutrient_key = nutrient_key[0] if nutrient_key else ""
    if not nutrient_key:
        return jsonify({
            "fulfillmentMessages": [{"text": {"text": ["Sorry, I couldn’t tell which nutrient you meant. Try asking again."]}}]
        })
    nutrient_key = nutrient_key.lower().replace(" ", "_")

    current_dir = os.path.dirname(__file__)
    nutrient_path = os.path.join(current_dir, "..", "data", "nutrient_info.json")
    try:
        with open(nutrient_path, encoding="utf-8") as f:
            nutrient_info = json.load(f)
    except Exception as e:
        print(f"[ERROR] Failed to load nutrient_info.json: {e}")
        return jsonify({
            "fulfillmentMessages": [{"text": {"text": ["Oops! I had trouble accessing the nutrient database."]}}]
        })

    nutrient = nutrient_info.get(nutrient_key)
    if nutrient and "sources" in nutrient:
        foods = ", ".join(nutrient["sources"])
        response_text = f"NHS recommended ways to get {nutrient['name']}: {foods}."
    else:
        response_text = f"Sorry, I couldn’t find foods high in {nutrient_key}."

    return jsonify({
        "fulfillmentMessages": [{"text": {"text": [response_text]}}]
    })


def handle_general_nutrition_info(req, nutrition_knowledge):
    user_question = req.get("queryResult", {}).get("queryText", "").lower()
    response = get_general_nutrition_response(user_question)
    return jsonify({
        "fulfillmentMessages": [{"text": {"text": [response]}}]
    })



def handle_get_rdi_for_nutrient(req):
    parameters = req.get("queryResult", {}).get("parameters", {})
    nutrient_key = parameters.get("nutrient", "")
    if isinstance(nutrient_key, list):
        nutrient_key = nutrient_key[0]
    nutrient_key = nutrient_key.lower().replace(" ", "_")

    current_dir = os.path.dirname(__file__)
    nutrient_path = os.path.join(current_dir, "..", "data", "nutrient_info.json")

    try:
        with open(nutrient_path, encoding="utf-8") as f:
            nutrient_info = json.load(f)
    except Exception as e:
        print(f"[ERROR] Failed to load nutrient_info.json: {e}")
        return jsonify({
            "fulfillmentMessages": [{"text": {"text": ["Sorry, I couldn't access nutrient data right now."]}}]
        })

    nutrient = nutrient_info.get(nutrient_key)
    if nutrient and "rdi" in nutrient:
        response_text = f"The NHS's recommended daily intake for {nutrient['name']} is: {nutrient['rdi']}."
    else:
        response_text = f"Sorry, I don’t have the RDI information for {nutrient_key}."

    return jsonify({
        "fulfillmentMessages": [{"text": {"text": [response_text]}}]
    })