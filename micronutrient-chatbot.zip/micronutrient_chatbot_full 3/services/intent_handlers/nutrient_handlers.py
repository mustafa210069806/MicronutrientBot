import re


def extract_numeric_amount(text):
    """Extracts the first float-like number from a string like '2.46 µg (98.4 IU)'."""
    if isinstance(text, (int, float)):
        return text
    match = re.search(r"\d+\.?\d*", str(text))
    return float(match.group()) if match else 0
from flask import jsonify
from difflib import get_close_matches
from services.usda_service import get_nutrient_amount, get_full_nutrient_profile
from services.static_foods import get_static_food_recommendations
from services.utils import clean_food_names
import json, os


def handle_get_nutrient_amount(req):
    parameters = req.get("queryResult", {}).get("parameters", {})
    food = parameters.get("food") or parameters.get("food.original", "")
    nutrient = parameters.get("nutrient") or parameters.get("nutrient.original", "")

    nutrient_aliases = {
        "vitamin c": ["vitamin c", "vitimin c", "vit c", "ascorbic acid"],
        "vitamin d": ["vitamin d", "vit d", "cholecalciferol", "ergocalciferol"],
        "vitamin b12": ["vitamin b12", "b12", "cyanocobalamin"],
        "iron": ["iron", "fer", "ferrous"],
        "calcium": ["calcium", "ca"],
        "magnesium": ["magnesium", "mg"]
    }

    def correct_term(term, alias_dict):
        term = term.lower().strip()
        for key, variants in alias_dict.items():
            if term in variants:
                return key
            match = get_close_matches(term, variants, n=1, cutoff=0.9)
            if match:
                return key
        return term

    nutrient = correct_term(nutrient, nutrient_aliases)
    food = food.lower().strip()
    if food.endswith("s"):
        food = food[:-1]

    if not food or not nutrient:
        return jsonify({
            "fulfillmentMessages": [
                {"text": {"text": ["Please tell me both the food and the nutrient you're interested in."]}}
            ]
        })

    amount, unit = get_nutrient_amount(food, nutrient)

    
    if amount is None or unit is None:
        print(f"[ERROR] Missing amount or unit for {nutrient} in {food}: amount={amount}, unit={unit}")
        return jsonify({
            "fulfillmentMessages": [{"text": {"text": [f"Sorry, I couldn't find the amount of {nutrient} in {food}."]}}]
        })

    
    if isinstance(amount, str) and unit in amount:
        base_reply = f"{food.title()} contains about {amount} of {nutrient} per 100g."
    else:
        base_reply = f"{food.title()} contains about {amount} {unit} of {nutrient} per 100g."

    followup_question = "Would you like to know what percentage of your daily recommended intake that is?"
    response_text = f"{base_reply} {followup_question}"

    return jsonify({
        "fulfillmentMessages": [
            {"text": {"text": [response_text]}}
        ],
        "outputContexts": [
            {
                "name": f"{req['session']}/contexts/awaiting_rdi",
                "lifespanCount": 5,
                "parameters": {
                    "nutrient": nutrient,
                    "food": food,
                    "amount": extract_numeric_amount(amount)
                }
            }
        ]
    })

def handle_nutrient_deficiency(req):
    parameters = req.get("queryResult", {}).get("parameters", {})
    nutrient_raw = parameters.get("nutrient", "")
    print("DEBUG - nutrient_raw:", nutrient_raw)

    if not nutrient_raw:
        return jsonify({
            "fulfillmentMessages": [{"text": {"text": ["Which nutrient are you asking about?"]}}]
        })

    nutrient_path = os.path.join("services", "data", "nutrient_info.json")
    try:
        with open(nutrient_path, encoding="utf-8") as f:
            nutrient_data = json.load(f) or {}
            print("DEBUG - nutrient_data loaded, number of entries:", len(nutrient_data))
            from difflib import get_close_matches

            nutrient_raw_lower = nutrient_raw.strip().lower()

            
            entry = next(
                (item for item in nutrient_data.values()
                 if item.get("name", "").strip().lower() == nutrient_raw_lower),
                None
            )

            print("DEBUG - matched entry:", entry)
            if entry:
                deficiency = entry.get("deficiency")
                name = entry.get("name")
            else:
                deficiency = None
                name = nutrient_raw.title()
    except Exception as e:
        print(f"[ERROR] Failed to load nutrient deficiency info: {e}")
        deficiency = None
        name = nutrient_raw.title()

    if deficiency:
        response = f"{name} deficiency: {deficiency}"
    else:
        response = f"Sorry, I don't have detailed deficiency info for {name}. Want food suggestions anyway?"

    print("DEBUG - final deficiency response:", response)

    return jsonify({
        "fulfillmentMessages": [{"text": {"text": [response]}}],
        # "outputContexts": [
        #     {
        #         "name": f"{req['session']}/contexts/awaiting_meal_consent",
        #         "lifespanCount": 5,
        #         "parameters": {
        #             "nutrient": name.lower()
        #         }
        #     }
        # ]
    })

def handle_get_full_nutrient_profile(req):
    parameters = req.get("queryResult", {}).get("parameters", {})
    food = parameters.get("food", "")
    if isinstance(food, list):
        food = food[0]
    food = food.strip().lower()

    if not food:
        return jsonify({
            "fulfillmentMessages": [
                {"text": {"text": ["What food would you like the nutrient profile for?"]}}
            ]
        })

    nutrients = get_full_nutrient_profile(food)

    if isinstance(nutrients, dict) and nutrients:
        formatted_nutrients = "\n".join([f"{k}: {v}" for k, v in nutrients.items()])
        response_text = f"Nutrient profile for {food.title()}:\n{formatted_nutrients}"
    else:
        response_text = f"Sorry, I couldn’t find the full nutrient profile for {food}."

    return jsonify({
        "fulfillmentMessages": [
            {"text": {"text": [response_text]}}
        ]
    })

def handle_nutrient_based(req):
    parameters = req.get("queryResult", {}).get("parameters", {})
    nutrient = parameters.get("nutrient", "")
    if isinstance(nutrient, list):
        nutrient = nutrient[0]
    nutrient = nutrient.lower()

    if nutrient:
        static_foods = get_static_food_recommendations()
        nutrient_foods = static_foods.get(nutrient, {})
        foods = []
        for category in nutrient_foods.values():
            foods.extend(category)
        cleaned_foods = clean_food_names(foods)

        if cleaned_foods:
            response_text = f"Sure! Some foods rich in {nutrient} include: {', '.join(cleaned_foods)}. Want more suggestions?"
        else:
            response_text = "I had trouble retrieving food data. Try again later."
    else:
        response_text = "Sorry, I couldn't identify the nutrient."

    return jsonify({
        "fulfillmentMessages": [
            {"text": {"text": [response_text]}}
        ],
        "outputContexts": [
            {
                "name": f"{req['session']}/contexts/awaiting_more",
                "lifespanCount": 5,
                "parameters": {
                    "nutrient": nutrient
                }
            }
        ]
    })

def handle_nutrient_overdose(req):
    parameters = req.get("queryResult", {}).get("parameters", {})
    nutrient_raw = parameters.get("nutrient", "")
    if isinstance(nutrient_raw, list):
        nutrient_raw = nutrient_raw[0]
    print("DEBUG - nutrient_raw:", nutrient_raw)

    if not nutrient_raw:
        return jsonify({
            "fulfillmentMessages": [{"text": {"text": ["Which nutrient are you asking about?"]}}]
        })

    nutrient_path = os.path.join("services", "data", "nutrient_info.json")
    try:
        with open(nutrient_path, encoding="utf-8") as f:
            nutrient_data = json.load(f) or {}
            nutrient_raw_lower = nutrient_raw.strip().lower()

           
            entry = next(
                (item for item in nutrient_data.values()
                 if item.get("name", "").strip().lower() == nutrient_raw_lower),
                None
            )
            print("DEBUG - matched entry:", entry)
            if entry:
                overdose = entry.get("overdose")
                name = entry.get("name")
            else:
                overdose = None
                name = nutrient_raw.title()
    except Exception as e:
        print(f"[ERROR] Failed to load nutrient overdose info: {e}")
        overdose = None
        name = nutrient_raw.title()

    if overdose:
        response = f"{name} overdose: {overdose}"
    else:
        response = f"Sorry, I don’t have overdose information for {name}."

    print("DEBUG - final overdose response:", response)

    return jsonify({
        "fulfillmentMessages": [{"text": {"text": [response]}}]
    })
