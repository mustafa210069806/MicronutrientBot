def get_static_food_recommendations():
    return {
        "iron": {
            "meats": ["Beef liver", "Chicken thigh", "Turkey leg", "Lamb chops"],
            "vegetables": ["Spinach", "Kale", "Swiss chard", "Collard greens"],
            "legumes": ["Lentils", "Chickpeas", "Kidney beans", "Soybeans"],
            "grains": ["Fortified breakfast cereals", "Quinoa", "Brown rice", "Oats"],
            "fruits": ["Dried apricots", "Prunes", "Raisins", "Mulberries"]
        },
        "vitamin c": {
            "fruits": ["Oranges", "Kiwis", "Strawberries", "Papaya"],
            "vegetables": ["Red bell peppers", "Broccoli", "Brussels sprouts", "Cauliflower"]
        },
        "vitamin d": {
            "meats": ["Salmon", "Tuna", "Mackerel"],
            "dairy": ["Fortified milk", "Fortified orange juice", "Fortified yoghurt"],
            "other": ["Egg yolks", "Mushrooms exposed to sunlight"]
        },
        "calcium": {
            "dairy": ["Milk", "Cheese", "Yogurt"],
            "vegetables": ["Bok choy", "Broccoli", "Turnip greens"],
            "fortified": ["Fortified soy milk", "Fortified tofu"]
        },
        "zinc": {
            "meats": ["Beef", "Pork", "Lamb"],
            "seafood": ["Oysters", "Crab", "Lobster"],
            "legumes": ["Chickpeas", "Lentils", "Beans"],
            "nuts and seeds": ["Pumpkin seeds", "Cashews", "Sunflower seeds"]
        },
        "vitamin b12": {
            "meats": ["Liver", "Beef", "Chicken"],
            "seafood": ["Clams", "Trout", "Salmon", "Tuna"],
            "dairy": ["Milk", "Cheese", "Yogurt"],
            "fortified": ["Fortified cereals", "Fortified nutritional yeast"]
        },
        "folate": {
            "vegetables": ["Spinach", "Asparagus", "Brussels sprouts"],
            "legumes": ["Black-eyed peas", "Lentils", "Kidney beans"],
            "grains": ["Fortified cereals", "Brown rice", "Whole wheat bread"],
            "fruits": ["Oranges", "Bananas", "Avocados"]
        },
        "magnesium": {
            "nuts and seeds": ["Almonds", "Pumpkin seeds", "Chia seeds"],
            "grains": ["Brown rice", "Quinoa", "Oats"],
            "legumes": ["Black beans", "Edamame", "Lentils"],
            "vegetables": ["Spinach", "Swiss chard", "Avocado"]
        },
        "potassium": {
            "fruits": ["Bananas", "Oranges", "Cantaloupe", "Apricots"],
            "vegetables": ["Potatoes", "Sweet potatoes", "Spinach", "Beets"],
            "legumes": ["Lima beans", "Lentils", "Kidney beans"],
            "dairy": ["Milk", "Yogurt"]
        },
        "selenium": {
            "meats": ["Beef", "Chicken", "Turkey"],
            "seafood": ["Tuna", "Sardines", "Halibut"],
            "nuts": ["Brazil nuts", "Sunflower seeds"],
            "grains": ["Brown rice", "Whole wheat bread", "Barley"]
        },
        "vitamin a": {
            "vegetables": ["Carrots", "Sweet potatoes", "Spinach", "Kale"],
            "fruits": ["Mango", "Cantaloupe", "Apricots"],
            "dairy": ["Milk", "Cheese"],
            "meats": ["Beef liver"]
        },
        "vitamin e": {
            "nuts and seeds": ["Almonds", "Sunflower seeds", "Hazelnuts"],
            "oils": ["Sunflower oil", "Wheat germ oil", "Safflower oil"],
            "vegetables": ["Spinach", "Broccoli"]
        },
        "vitamin k": {
            "vegetables": ["Kale", "Spinach", "Broccoli", "Brussels sprouts"],
            "oils": ["Soybean oil", "Canola oil"]
        },
        "thiamine (b1)": {
            "grains": ["Whole wheat bread", "Brown rice", "Oats"],
            "meats": ["Pork", "Ham"],
            "legumes": ["Black beans", "Navy beans"]
        },
        "riboflavin (b2)": {
            "dairy": ["Milk", "Yogurt"],
            "meats": ["Beef liver", "Lean beef"],
            "grains": ["Fortified cereals", "Whole grain breads"]
        },
        "niacin (b3)": {
            "meats": ["Chicken breast", "Tuna", "Turkey"],
            "grains": ["Brown rice", "Fortified cereals"],
            "legumes": ["Peanuts", "Lentils"]
        },
        "pantothenic acid (b5)": {
            "meats": ["Chicken liver", "Salmon", "Beef"],
            "vegetables": ["Mushrooms", "Avocados", "Sweet potatoes"]
        },
        "pyridoxine (b6)": {
            "meats": ["Chicken", "Turkey", "Pork"],
            "vegetables": ["Bananas", "Potatoes", "Spinach"],
            "grains": ["Oats", "Fortified cereals"]
        },
        "biotin (b7)": {
            "eggs": ["Egg yolks"],
            "nuts": ["Almonds", "Walnuts"],
            "vegetables": ["Sweet potatoes", "Spinach"],
            "grains": ["Whole grains"]
        },
        "iodine": {
            "seafood": ["Cod", "Tuna", "Seaweed"],
            "dairy": ["Milk", "Cheese", "Yogurt"],
            "fortified": ["Iodised salt"]
        },
        "chromium": {
            "grains": ["Whole grains"],
            "meats": ["Beef", "Turkey"],
            "vegetables": ["Broccoli", "Potatoes"]
        },
        "manganese": {
            "grains": ["Brown rice", "Oats"],
            "nuts": ["Hazelnuts", "Pecans", "Macadamia"],
            "vegetables": ["Spinach", "Sweet potatoes"]
        },
        "copper": {
            "seafood": ["Oysters", "Crab"],
            "nuts": ["Cashews", "Almonds"],
            "grains": ["Whole grains"],
            "legumes": ["Lentils", "Soybeans"]
        },
        "fluoride": {
            "water": ["Fluoridated drinking water"],
            "seafood": ["Shrimp", "Crab"]
        },
        "molybdenum": {
            "legumes": ["Lentils", "Beans"],
            "grains": ["Whole grains"],
            "nuts": ["Peanuts", "Almonds"]
        }
    }