import os
import pandas as pd


MEAL_DATA_DIR = "services/data/meals"


def load_all_meals():
    all_files = [f for f in os.listdir(MEAL_DATA_DIR) if f.endswith(".csv")]
    dfs = []
    for file in all_files:
        path = os.path.join(MEAL_DATA_DIR, file)
        df = pd.read_csv(path)
        dfs.append(df)
    return pd.concat(dfs, ignore_index=True)


MEAL_DATAFRAME = load_all_meals()

def get_meals(target_nutrient=None, diet_type=None, meal_type=None):
    df = MEAL_DATAFRAME.copy()
    if target_nutrient:
        df = df[df["Target_Nutrient"].str.lower() == target_nutrient.lower()]
    if diet_type:
        df = df[df["Diet_Type"].str.lower() == diet_type.lower()]
    if meal_type:
        df = df[df["Meal_Type"].str.lower() == meal_type.lower()]
    return df.reset_index(drop=True)