import requests
from difflib import get_close_matches

API_KEY = "YRDqj9ggNiDLBCoA3DSuFJe3dYC2PXS6LzF6IKrf"
SEARCH_URL = "https://api.nal.usda.gov/fdc/v1/foods/search"
DETAIL_URL = "https://api.nal.usda.gov/fdc/v1/food/{}"


NUTRIENT_SYNONYMS = {
    "vitamin c": ["vitamin c, total ascorbic acid"],
    "vitamin a": ["vitamin a, rae"],
    "vitamin b12": ["vitamin b-12"],
    "vitamin d": ["vitamin d (d2 + d3)", "vitamin d3", "vitamin d2"],
    "vitamin k": ["vitamin k", "vitamin k (phylloquinone)"],
    "iron": ["iron, fe"],
    "calcium": ["calcium, ca"],
    "magnesium": ["magnesium, mg"],
    "potassium": ["potassium, k"],
    "zinc": ["zinc, zn"],
    "folate": ["folate, total"],
    "fiber": ["fiber, total dietary"],
    "omega 3": ["fatty acids, total omega-3"]
}

WHOLE_FOOD_KEYWORDS = ["raw", "fresh", "whole", "natural", "unprocessed", "plain"]
PROCESSED_FOOD_KEYWORDS = ["juice", "cooked", "fried", "baked", "grilled", "lasagna", "burger", "nuggets", "snack", "powder", "flavored", "seasoned"]

def normalise(name):
    return name.lower().replace("(", "").replace(")", "").replace(",", "").replace("  ", " ").strip()

def search_and_rank_foods(food_name):
    food_name = food_name.lower().replace("-", " ").replace("_", " ").strip()
    search_params = {
        "api_key": API_KEY,
        "query": food_name,
        "requireAllWords": True,
        "dataType": ["Foundation", "SR Legacy"],
        "pageSize": 6
    }
    search_response = requests.get(SEARCH_URL, params=search_params)
    search_response.raise_for_status()
    results = search_response.json().get("foods", [])

    def score_food_label(label):
        label = label.lower()
        score = 0
        for word in WHOLE_FOOD_KEYWORDS:
            if word in label:
                score += 1
        for word in PROCESSED_FOOD_KEYWORDS + ["peel", "juice", "babyfood", "puree", "snack", "drink", "powder"]:
            if word in label:
                score -= 2
        return score

    return sorted(results, key=lambda food: score_food_label(food.get("description", "")), reverse=True)

def get_nutrient_amount(food_name, nutrient_name):
    try:
        print(f"DEBUG: USDA nutrient query — food: {food_name}, nutrient: {nutrient_name}")

        food_name = food_name.lower().replace("-", " ").replace("_", " ").strip()

        sorted_results = search_and_rank_foods(food_name)

        for food in sorted_results:
            fdc_id = food.get("fdcId")
            if not fdc_id:
                continue

            detail_response = requests.get(DETAIL_URL.format(fdc_id), params={"api_key": API_KEY})
            detail_response.raise_for_status()
            food_data = detail_response.json()

            food_label = food_data.get("description", "(no label)")
            print(f"DEBUG: Checking nutrients for food: {food_label}")

            nutrients = food_data.get("foodNutrients", [])
            print("DEBUG: Raw USDA nutrient names:")
            cleaned_names = {}
            vitamin_d_ug = None
            vitamin_d_iu = None

            for n in nutrients:
                nutrient_info = n.get("nutrient")
                if nutrient_info:
                    name = nutrient_info.get("name")
                    unit = nutrient_info.get("unitName")
                    value = n.get("amount")
                    print(f" - {name} ({unit}): {value}")
                    if name and unit and value is not None:
                        normalised = normalise(name)
                        cleaned_names[normalised] = {
                            "value": value,
                            "unitName": unit
                        }
                        if "vitamin d" in normalise(name):
                            if "iu" in unit.lower():
                                vitamin_d_iu = value
                            elif "µg" in unit.lower() or "ug" in unit.lower() or "mcg" in unit.lower():
                                vitamin_d_ug = value

            # Check for vitamin D specifically because of the Egg issue
            if normalise(nutrient_name) == "vitamin d":
                if vitamin_d_ug is not None and vitamin_d_ug > 0:
                    combined = f"{vitamin_d_ug} µg"
                    if vitamin_d_iu is not None and vitamin_d_iu > 0:
                        combined += f" ({vitamin_d_iu} IU)"
                    print(f"DEBUG: Combined vitamin D value → {combined}")
                    return combined, "µg"
                elif vitamin_d_iu is not None and vitamin_d_iu > 0:
                    print(f"DEBUG: Fallback to IU for vitamin D → {vitamin_d_iu} IU")
                    return f"{vitamin_d_iu} IU", "IU"
                else:
                    print("DEBUG: No usable vitamin D value found")
                    return None, None

            # synonyms first
            synonyms = NUTRIENT_SYNONYMS.get(nutrient_name.lower(), [])
            for synonym in synonyms:
                match = cleaned_names.get(normalise(synonym))
                if match:
                    amount = match.get("value")
                    unit = match.get("unitName")
                    print(f"DEBUG: Matched nutrient via synonym: {synonym} → {amount} {unit}")
                    return amount, unit

            #  fuzzy match as fallback
            close_matches = get_close_matches(normalise(nutrient_name), cleaned_names.keys(), n=1, cutoff=0.85)
            if not close_matches:
                print(f"DEBUG: No fuzzy match found for nutrient: {nutrient_name}")
                return None, None

            best_match = close_matches[0]
            match = cleaned_names[best_match]
            amount = match.get("value")
            unit = match.get("unitName")
            print(f"DEBUG: Fuzzy matched nutrient: {best_match} → {amount} {unit}")
            return amount, unit

            print(f"DEBUG: No match found in fdcId={fdc_id} → skipping")

        print(f"DEBUG: Failed to find nutrient match for: {nutrient_name} in {food_name}")
        return None, None

    except Exception as e:
        print(f"ERROR in get_nutrient_amount: {e}")
        return None, None

def get_full_nutrient_profile(food_name):
    try:
        print(f"DEBUG: USDA full profile query — food: {food_name}")
        food_name = food_name.lower().replace("-", " ").replace("_", " ").strip()
        sorted_results = search_and_rank_foods(food_name)

        for food in sorted_results:
            fdc_id = food.get("fdcId")
            if not fdc_id:
                continue

            detail_response = requests.get(DETAIL_URL.format(fdc_id), params={"api_key": API_KEY})
            detail_response.raise_for_status()
            food_data = detail_response.json()

            food_label = food_data.get("description", "(no label)")
            print(f"DEBUG: Full nutrient list for: {food_label}")

            nutrients = food_data.get("foodNutrients", [])
            nutrient_lines = []

            for n in nutrients:
                nutrient_info = n.get("nutrient")
                if nutrient_info:
                    name = nutrient_info.get("name")
                    unit = nutrient_info.get("unitName")
                    value = n.get("amount")
                    if name and unit and value is not None:
                        line = f"- {name} ({unit}): {value}"
                        nutrient_lines.append(line)

            if nutrient_lines:
                key_nutrients = [
                    "Energy", "Protein", "Total lipid (fat)", "Carbohydrate, by difference", "Fiber, total dietary",
                    "Calcium, Ca", "Iron, Fe", "Magnesium, Mg", "Potassium, K", "Zinc, Zn",
                    "Vitamin C, total ascorbic acid", "Vitamin B-12", "Vitamin A, RAE", "Vitamin D (D2 + D3)",
                    "Vitamin E (alpha-tocopherol)", "Vitamin K (phylloquinone)"
                ]
                
                filtered = {}
                for n in nutrients:
                    nutrient_info = n.get("nutrient")
                    if nutrient_info:
                        name = nutrient_info.get("name")
                        unit = nutrient_info.get("unitName")
                        value = n.get("amount")
                        if name in key_nutrients and value is not None:
                            filtered[name] = f"{value} {unit}"
                
                return {
                    "food": food_label,
                    "nutrients": filtered
                }
            else:
                print(f"DEBUG: No nutrients found in fdcId={fdc_id} → skipping")

        return None
    except Exception as e:
        print(f"ERROR in get_full_nutrient_profile: {e}")
        return None