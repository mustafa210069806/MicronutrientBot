import json
import os
from difflib import get_close_matches

knowledge_file_path = os.path.join(os.path.dirname(__file__), "data", "nutrition_knowledge.json")

def load_nutrition_knowledge():
    try:
        with open(knowledge_file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except Exception as e:
        print(f"ERROR: Could not load knowledge file: {e}")
        return {}

def get_general_nutrition_response(user_question):
    knowledge = load_nutrition_knowledge()
    questions = list(knowledge.keys())

    match = get_close_matches(user_question.lower(), questions, n=1, cutoff=0.6)
    if match:
        best_match = match[0]
        return knowledge[best_match]
    else:
        return "Sorry, I couldn’t find a good answer for that. Try asking in a different way."

def load_general_nutrition_knowledge():
    return load_nutrition_knowledge()