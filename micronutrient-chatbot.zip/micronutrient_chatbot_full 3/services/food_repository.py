

import pandas as pd

def get_foods_for_nutrient(nutrient_name: str, limit=5):
    """
    Returns a list of food items rich in the specified nutrient.
    Each item is a dictionary with 'food', 'nutrient', 'diet_type', and 'source'.
    """
    df = pd.read_csv("services/data/nutrient_food_map.csv")
    matches = df[df["nutrient"].str.lower() == nutrient_name.lower()]
    return matches.sample(n=min(limit, len(matches))).to_dict("records") if not matches.empty else []