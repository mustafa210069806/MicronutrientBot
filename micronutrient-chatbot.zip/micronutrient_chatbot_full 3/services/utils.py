def clean_food_names(food_items):
    cleaned = []
    for item in food_items:
        name = item.lower().strip()

        # Remove weight/quantity info
        name = re.sub(r'\b\d+\s*(g|kg|ml|l|oz|pounds?|cups?|tablespoons?|tbsp|teaspoons?|tsp|slices?)\b', '', name)

        # Remove size adjectives
        name = re.sub(r'\b(extra[-\s]?)?(small|medium|large|big|huge|tiny)\b', '', name)

        # Remove standalone numbers
        name = re.sub(r'\b\d+\b', '', name)

        # Clean up and title case
        name = re.sub(r'\s+', ' ', name).strip().title()

        if name and name not in cleaned:
            cleaned.append(name)
        if len(cleaned) >= 5:
            break
    return cleaned

import re

def convert_height_to_cm(height):
    height = height.lower().strip()

    # scrapped code
    match = re.match(r"(\d+)\s*(foot|feet|ft|')\s*(\d+)?", height)
    if match:
        feet = int(match.group(1))
        inches = int(match.group(3)) if match.group(3) else 0
        return feet * 30.48 + inches * 2.54

    # scrapped code
    elif "cm" in height:
        return float(height.replace("cm", "").strip())

    return None

def convert_weight_to_kg(weight):
    if "lb" in weight.lower() or "pound" in weight.lower():
        return float(weight.replace("lb", "").replace("pound", "").strip()) * 0.453592
    elif "kg" in weight.lower():
        return float(weight.replace("kg", "").strip())
    return None
from flask import jsonify
# No intent
def handle_no_intent(req):
    session = req.get('session', '')
    return jsonify({
        "fulfillmentText": "Okay, no problem. Let me know if you need anything else!",
        "outputContexts": [
            {
                "name": f"{session}/contexts/awaiting_user_profile",
                "lifespanCount": 0
            },
            {
                "name": f"{session}/contexts/awaiting_rdi",
                "lifespanCount": 0
            },
            {
                "name": f"{session}/contexts/awaiting_meal_consent",
                "lifespanCount": 0
            }
        ]
    })