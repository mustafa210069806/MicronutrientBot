import os
from google.cloud import dialogflow_v2 as dialogflow
from google.api_core.exceptions import InvalidArgument
import json


os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "dialogflow_key.json"


DIALOGFLOW_PROJECT_ID = "micronutrientbot-jkmj"
DIALOGFLOW_LANGUAGE_CODE = "en"
SESSION_ID = "current-user-id"

def detect_intent_from_text(text_input, session_id=SESSION_ID):
    session_client = dialogflow.SessionsClient()
    session = session_client.session_path(DIALOGFLOW_PROJECT_ID, session_id)

    text_input = dialogflow.TextInput(text=text_input, language_code=DIALOGFLOW_LANGUAGE_CODE)
    query_input = dialogflow.QueryInput(text=text_input)

    try:
        response = session_client.detect_intent(
            request={"session": session, "query_input": query_input}
        )
    except InvalidArgument as e:
        raise

    return response.query_result.fulfillment_text
