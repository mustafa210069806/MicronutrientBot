

def get_rdi_value(nutrient, gender, age, weight_kg=None, height_cm=None):
    nutrient = nutrient.lower()
    gender = str(gender).strip().lower()
    try:
        age = int(float(age["amount"])) if isinstance(age, dict) else int(float(age))
    except:
        age = None
    print(f"DEBUG: Using age={age}, gender={gender} for RDI of {nutrient}")

   
    if nutrient == "vitamin k" and weight_kg:
        return round(weight_kg * 1.0, 1)  # µg

    if nutrient == "iron":
        if gender == "female" and 19 <= age <= 49:
            return 14.8
        return 8.7

    if nutrient == "folate":
        return 200

    if nutrient == "zinc":
        if gender == "male" and 19 <= age <= 94:
            return 9.5
        if gender == "female" and 19 <= age <= 94:
            return 7.0

    if nutrient == "magnesium":
        if gender == "male":
            return 300  # NHSrdi men
        if gender == "female":
            return 270  # for women

    if nutrient == "vitamin a":
        if gender == "male":
            return 700  # µg for men
        if gender == "female":
            return 600  #  for women

    if nutrient == "selenium":
        if gender == "male":
            return 75  # NHS RDI for men
        if gender == "female":
            return 60  #  for women

    if nutrient == "iodine":
        return 140  

    rdi_data = {
        "vitamin c": {"male": 40, "female": 40},
        "calcium": {"male": 700, "female": 700},
        "protein": {"male": 55.5, "female": 45},  
        "vitamin d": {"male": 10, "female": 10},
        "vitamin b12": {"male": 1.5, "female": 1.5},
    }

    return rdi_data.get(nutrient, {}).get(gender)


def convert_to_mg(amount, unit):
    unit = unit.lower()
    if unit == 'µg' or unit == 'mcg':
        return amount / 1000
    if unit == 'g':
        return amount * 1000
    if unit == 'mg':
        return amount
    return None


def calculate_rdi_percentage(amount, unit, nutrient, gender, age, weight_kg=None, height_cm=None):
    try:
        age = int(float(age))
    except:
        age = None

    try:
        weight_kg = float(weight_kg) if weight_kg else None
    except:
        weight_kg = None

    try:
        height_cm = float(height_cm) if height_cm else None
    except:
        height_cm = None

    try:
        if isinstance(amount, str):
            amount = amount.split()[0].replace(",", "")
        amount = float(amount)
    except:
        print(f"DEBUG: Invalid amount: {amount}")
        return None

    print(f"DEBUG: Calculating %RDI for nutrient={nutrient}, amount={amount}, unit={unit}, gender={gender}, age={age}, weight={weight_kg}, height={height_cm}")

    if nutrient.lower() in ["protein", "calories"]:
        rdi_value = get_custom_rdi(nutrient, gender, age, weight_kg or 70, height_cm or 175)
    else:
        rdi_value = get_rdi_value(nutrient, gender, age, weight_kg, height_cm)
        
        if unit.lower() in ["µg", "mcg"]:
            rdi_value = rdi_value / 1000

    if rdi_value is None:
        print(f"DEBUG: No RDI found for {nutrient}")
        return None

    print(f"DEBUG: RDI value for {nutrient} is {rdi_value}")

    if nutrient.lower() == "protein":
       
        return round((amount / rdi_value) * 100, 1)

   
    converted = convert_to_mg(amount, unit)
    if converted is None:
        print(f"DEBUG: Unknown unit {unit}")
        return None

    print(f"DEBUG: Converted amount = {converted} mg")
    return round((converted / rdi_value) * 100, 1)


def get_custom_rdi(nutrient, gender, age, weight_kg, height_cm, activity="moderate"):
    nutrient = nutrient.lower()
    gender = gender.lower()

    try:
        age = int(float(age))
    except:
        age = None

    try:
        weight_kg = float(weight_kg)
        height_cm = float(height_cm)
    except:
        return get_rdi_value(nutrient, gender, age)

    # Custom logic for dynamic nutrients protien and calories scraped
    if nutrient == "protein":
        return round(0.75 * weight_kg, 2)  #

    elif nutrient == "calories":
        # Mifflin-St Jeor Equation
        if gender == "male":
            bmr = 10 * weight_kg + 6.25 * height_cm - 5 * age + 5
        else:
            bmr = 10 * weight_kg + 6.25 * height_cm - 5 * age - 161

        multiplier = 1.55  #  future implementation for 
        return round(bmr * multiplier, 0)

   
    return get_rdi_value(nutrient, gender, age)