import requests
from bs4 import BeautifulSoup
import json

def extract_sections(soup):
    sections = {}
    current_heading = None

    for tag in soup.find_all(['h2', 'p', 'ul']):
        if tag.name == 'h2':
            current_heading = tag.get_text(strip=True).lower()
            sections[current_heading] = []
        elif current_heading:
            if tag.name == 'p':
                sections[current_heading].append(tag.get_text(strip=True))
            elif tag.name == 'ul':
                items = [li.get_text(strip=True) for li in tag.find_all('li')]
                sections[current_heading].extend(items)
    
    return sections

def clean_sources_list(source_list):
    return [item for item in source_list if not any(keyword in item.lower() for keyword in ["good source", "include", "examples of"])]

def structure_nutrient_data(name, sections):
    def match_section(keywords):
        for heading, content in sections.items():
            if any(keyword in heading for keyword in keywords):
                return content
        return []

    role = match_section(["what", "why", "need", "does"])
    sources = clean_sources_list(match_section(["source", "food", "eat"]))
    rdi = match_section(["how much", "recommended", "amount"])
    deficiency = match_section(["deficiency", "don't get", "do not get", "too little", "lack"])
    overdose = match_section(["too much", "overdose", "high dose"])

    return {
        "name": name.replace("_", " ").title(),
        "role": role[0] if role else "",
        "sources": sources,
        "rdi": rdi[0] if rdi else "",
        "deficiency": deficiency[0] if deficiency else "",
        "overdose": overdose[0] if overdose else ""
    }

def main():
    with open("services/data/vitamins.json", "r", encoding="utf-8") as f:
        vitamin_urls = json.load(f)

    all_data = {}

    for key, info in vitamin_urls.items():
        url = info.get("url")
        if not url:
            continue

        print(f"Scraping {key} → {url}")
        try:
            res = requests.get(url)
            soup = BeautifulSoup(res.text, 'html.parser')
            sections = extract_sections(soup)
            structured = structure_nutrient_data(key, sections)
            all_data[key] = structured
        except Exception as e:
            print(f"Failed to scrape {key}: {e}")

    with open("services/data/nutrient_info.json", "w", encoding="utf-8") as f:
        json.dump(all_data, f, indent=2, ensure_ascii=False)

if __name__ == "__main__":
    main()
