import requests
from bs4 import BeautifulSoup
import json
import os

def scrape_nhs_balanced_diet_page():
    url = "https://www.nhs.uk/live-well/eat-well/how-to-eat-a-balanced-diet/eating-a-balanced-diet/"
    response = requests.get(url)
    if response.status_code != 200:
        print("Failed to fetch NHS page.")
        return

    soup = BeautifulSoup(response.content, "html.parser")
    content_sections = soup.find_all(["h2", "h3", "p", "ul"])

    scraped_data = {}
    current_topic = None
    current_text = []

    for element in content_sections:
        if element.name in ["h2", "h3"]:
            if current_topic and current_text:
                scraped_data[current_topic] = " ".join(current_text).strip()
            current_topic = element.get_text(strip=True)
            current_text = []
        elif element.name == "p":
            current_text.append(element.get_text(strip=True))
        elif element.name == "ul":
            for li in element.find_all("li"):
                current_text.append("- " + li.get_text(strip=True))

    if current_topic and current_text:
        scraped_data[current_topic] = " ".join(current_text).strip()

    os.makedirs("services/data", exist_ok=True)
    with open("services/data/nutrition_knowledge.json", "w", encoding="utf-8") as f:
        json.dump(scraped_data, f, indent=2, ensure_ascii=False)

    print(" NHS data scraped and saved to services/data/nutrition_knowledge.json")

if __name__ == "__main__":
    scrape_nhs_balanced_diet_page()
